ROS package for the Robotis OP2 actuator and sensor control using the ros_controllers interface
